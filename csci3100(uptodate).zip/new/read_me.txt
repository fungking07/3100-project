replace C:\xampp\php\php.ini with github version to configure XAMsever to send mail
replace C:\xampp\sendmail\sendmail.ini with github version to configure XAMsever to send mail