    <!-- Filter
    <div class="col-md-2">
      The following code is adapt from https://www.w3schools.com/howto/howto_js_collapsible.asp 
      <button class="collapsible">Filter</button>
        <div class="content">
          <h3>Categroies:</h3>
          <input type="checkbox" id="ulife" name="ulife" value="ulife">
          <label for="ulife"> University life</label><br>
          <input type="checkbox" id="study" name="study" value="study">
          <label for="study"> University study</label><br>
          <input type="checkbox" id="career" name="career" value="career">
          <label for="career"> Future career</label><br>
          <hr>
          <h3>Post date:</h3>
          <input type="checkbox" id="1wless" name="1wless" value="1wless">
          <label for="1wless"> Less than 1 week</label><br>
          <input type="checkbox" id="1wto2w" name="1wto2w" value="1wto2w">
          <label for="1wto2w"> 1 week to 2 weeks</label><br>
          <input type="checkbox" id="2wto1m" name="2wto1m" value="2wto1m">
          <label for="2wto1m"> 2 weeks to 1 month</label><br>
          <input type="checkbox" id="1mup" name="1mup" value="1mup">
          <label for="1mup"> More then 1 month</label><br>
          <hr>
          <h3>Likes:</h3>
          <input type="checkbox" id="10lesslikes" name="10lesslikes" value="10lesslikes">
          <label for="10lesslikes"> Less than 10 likes</label><br>
          <input type="checkbox" id="10to50likes" name="10to50likes" value="10to50likes">
          <label for="10to50likes"> 10 to 50 likes</label><br>
          <input type="checkbox" id="50to100likes" name="50to100likes" value="50to100likes">
          <label for="50to100likes"> 50 to 100 likes</label><br>
          <input type="checkbox" id="100uplikes" name="100uplikes" value="100uplikes">
          <label for="100uplikes"> More than 100 likes</label><br>
          <hr>
          <a href="#" class="btn btn-success">Find Post</a>
        </div>
      </div>
      Adapatation ends here
    </div> -->