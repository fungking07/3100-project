<?php
 define('BASEURL', $_SERVER['DOCUMENT_ROOT'].'/csci3100-project');
 echo BASEURL;
 ?>
